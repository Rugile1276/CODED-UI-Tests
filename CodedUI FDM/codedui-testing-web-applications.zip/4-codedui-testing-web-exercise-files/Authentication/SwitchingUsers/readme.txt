You need to restore the nuget packages first before the solution compiles correctly
Right click the solution and choose "Manage nuget packages for solution"
in the following dialog at the top you see a message that packages are missing
please click the restore option there and the pckages are downloaded.

with kind regards,
Marcel